BANDIT_LEVELS = {
    0: {
        "level": "Level 0",
        "description": "The goal of this level is to log into the game using SSH.",
        "objective": "Log into bandit.labs.overthewire.org on port 2220 using username 'bandit0' and password 'bandit0'.",
        "hints": [
            "SSH is a protocol used to securely connect to remote servers",
            "The password for this level is: bandit0",
            "You can use the web terminal or your own SSH client"
        ],
        "useful_commands": ["ssh"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit0.html"]
    },
    1: {
        "level": "Level 0 → Level 1",
        "description": "The password for the next level is stored in a file called readme located in the home directory.",
        "objective": "Find and read the content of the 'readme' file to get the password for Level 1.",
        "hints": [
            "Use ls to list files in the current directory",
            "Use cat to read file contents",
            "The file is in the home directory, which is where you start"
        ],
        "useful_commands": ["ls", "cat", "pwd"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit1.html"]
    },
    2: {
        "level": "Level 1 → Level 2",
        "description": "The password for the next level is stored in a file called '-' located in the home directory.",
        "objective": "Read the content of a file named '-'.",
        "hints": [
            "Dashes in filenames require special handling",
            "Try using ./ before the filename",
            "You can also use the full path to the file"
        ],
        "useful_commands": ["ls", "cat", "pwd"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit2.html"]
    },
    3: {
        "level": "Level 2 → Level 3",
        "description": "The password for the next level is stored in a file called 'spaces in this filename' located in the home directory.",
        "objective": "Read a file that has spaces in its name.",
        "hints": [
            "Spaces in filenames need to be handled specially",
            "You can use quotes around the filename",
            "You can escape spaces with a backslash"
        ],
        "useful_commands": ["ls", "cat", "pwd"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit3.html"]
    },
    4: {
        "level": "Level 3 → Level 4",
        "description": "The password for the next level is stored in a hidden file in the inhere directory.",
        "objective": "Find and read a hidden file in the 'inhere' directory.",
        "hints": [
            "Hidden files in Linux start with a dot (.)",
            "Use ls -a to show hidden files",
            "You'll need to change directory into 'inhere' first"
        ],
        "useful_commands": ["ls", "ls -la", "cd", "cat"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit4.html"]
    },
    5: {
        "level": "Level 4 → Level 5",
        "description": "The password for the next level is stored in the only human-readable file in the inhere directory.",
        "objective": "Find the human-readable file in the 'inhere' directory and read its contents.",
        "hints": [
            "There are multiple files in the directory",
            "Try reading each file to find which one contains text",
            "The file command can help identify file types"
        ],
        "useful_commands": ["ls", "cd", "cat", "file"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit5.html"]
    },
    6: {
        "level": "Level 5 → Level 6",
        "description": "The password is stored in a file somewhere under the inhere directory and has specific properties.",
        "objective": "Find a file with specific properties: human-readable, 1033 bytes in size, and not executable.",
        "hints": [
            "Use the find command to search for files with specific properties",
            "You can combine multiple conditions in your search",
            "Check file sizes with ls -l"
        ],
        "useful_commands": ["ls", "find", "du", "file"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit6.html"]
    },
    7: {
        "level": "Level 6 → Level 7",
        "description": "The password is stored somewhere on the server and has specific properties.",
        "objective": "Find a file owned by user bandit7, group bandit6, and 33 bytes in size.",
        "hints": [
            "The file could be anywhere on the server",
            "Use find with user and group filters",
            "You might see some permission denied errors - that's normal"
        ],
        "useful_commands": ["find", "ls", "grep"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit7.html"]
    },
    8: {
        "level": "Level 7 → Level 8",
        "description": "The password for the next level is stored in the file data.txt next to the word millionth.",
        "objective": "Find the line containing 'millionth' in data.txt and get the password.",
        "hints": [
            "The file contains many lines",
            "You need to find a specific line containing a specific word",
            "Try using text processing commands"
        ],
        "useful_commands": ["grep", "cat"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit8.html"]
    },
    9: {
        "level": "Level 8 → Level 9",
        "description": "The password for the next level is stored in data.txt and is the only line of text that occurs only once.",
        "objective": "Find the unique line in data.txt.",
        "hints": [
            "The file contains many lines",
            "Most lines are repeated",
            "Look into commands that can help find unique lines"
        ],
        "useful_commands": ["sort", "uniq", "cat"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit9.html"]
    },
    10: {
        "level": "Level 9 → Level 10",
        "description": "The password for the next level is stored in data.txt in one of the few human-readable strings, preceded by several '=' characters.",
        "objective": "Find the human-readable string that starts with several '=' characters.",
        "hints": [
            "The file contains both text and binary data",
            "Look for strings preceded by '=' characters",
            "The strings command can help find readable text in binary files"
        ],
        "useful_commands": ["strings", "grep"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit10.html"]
    },
    11: {
        "level": "Level 10 → Level 11",
        "description": "The password for the next level is stored in data.txt, which contains base64 encoded data.",
        "objective": "Decode the base64 encoded data in data.txt.",
        "hints": [
            "Base64 is a common encoding method",
            "Linux has built-in commands for base64 decoding",
            "The decoded text will contain the password"
        ],
        "useful_commands": ["base64", "cat"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit11.html"]
    },
    12: {
        "level": "Level 11 → Level 12",
        "description": "The password for the next level is stored in data.txt, where all lowercase (a-z) and uppercase (A-Z) letters have been rotated by 13 positions.",
        "objective": "Decode the ROT13 encoded text in data.txt.",
        "hints": [
            "ROT13 is a simple substitution cipher",
            "Each letter is replaced by the letter 13 positions after it",
            "You can use tr command for character substitution"
        ],
        "useful_commands": ["cat", "tr"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit12.html"]
    },
    13: {
        "level": "Level 12 → Level 13",
        "description": "The password for the next level is stored in data.txt, which is a hexdump of a file that has been repeatedly compressed.",
        "objective": "Reverse the hexdump and decompress the file multiple times to get the password.",
        "hints": [
            "First, reverse the hexdump using xxd",
            "The file has been compressed multiple times with different tools",
            "Look at file headers or use the file command to identify compression types",
            "Create a working directory in /tmp"
        ],
        "useful_commands": ["xxd", "file", "gzip", "bzip2", "tar", "mkdir", "cd", "mv"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit13.html"]
    },
    14: {
        "level": "Level 13 → Level 14",
        "description": "The password for the next level is stored in /etc/bandit_pass/bandit14 and can only be read by user bandit14. A private SSH key is provided at ~/sshkey.private.",
        "objective": "Use the private SSH key to log into bandit14 and read the password file.",
        "hints": [
            "SSH can authenticate using private keys instead of passwords",
            "The key file permissions might need to be adjusted",
            "Once logged in as bandit14, you can read the password file"
        ],
        "useful_commands": ["ssh", "chmod", "cat"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit14.html"]
    },
    15: {
        "level": "Level 14 → Level 15",
        "description": "The password for the next level can be retrieved by submitting the current level's password to port 30000 on localhost.",
        "objective": "Connect to localhost port 30000 and send the current password to get the next password.",
        "hints": [
            "You can use nc (netcat) to connect to network ports",
            "The current password is in /etc/bandit_pass/bandit14",
            "The service will respond with the next password when given the correct input"
        ],
        "useful_commands": ["nc", "telnet", "cat"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit15.html"]
    },
    16: {
        "level": "Level 15 → Level 16",
        "description": "The password for the next level can be retrieved by submitting the current level's password to port 30001 on localhost using SSL encryption.",
        "objective": "Use SSL/TLS to connect to localhost port 30001 and submit the current password.",
        "hints": [
            "OpenSSL can be used for SSL/TLS connections",
            "The s_client command initiates SSL/TLS connections",
            "You'll need to submit the current level's password"
        ],
        "useful_commands": ["openssl", "s_client", "cat"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit16.html"]
    },
    17: {
        "level": "Level 16 → Level 17",
        "description": "The credentials for the next level can be retrieved by submitting the current level's password to a port on localhost in the range 31000 to 32000. A port speaks SSL and the password is the only correct line.",
        "objective": "Find the SSL service, connect to it, and submit the password to get SSH credentials.",
        "hints": [
            "First, scan for open ports in the given range",
            "Identify which port speaks SSL",
            "Use OpenSSL to connect to the correct port",
            "You'll receive an SSH private key as the response"
        ],
        "useful_commands": ["nmap", "openssl", "s_client", "nc"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit17.html"]
    },
    18: {
        "level": "Level 17 → Level 18",
        "description": "There are 2 files in the home directory: passwords.old and passwords.new. The password for the next level is in passwords.new and is the only line that has been changed between passwords.old and passwords.new.",
        "objective": "Find the line that differs between the two password files.",
        "hints": [
            "Compare the contents of both files",
            "Look for tools that can show differences between files",
            "The changed line contains the new password"
        ],
        "useful_commands": ["diff", "cat"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit18.html"]
    },
    19: {
        "level": "Level 18 → Level 19",
        "description": "The password for the next level is stored in a file readme in the home directory. Unfortunately, someone has modified .bashrc to log you out when you log in with SSH.",
        "objective": "Read the readme file despite being logged out immediately upon SSH login.",
        "hints": [
            "SSH can execute commands directly",
            "Try running commands through SSH without starting a shell",
            "The file is still accessible even if you can't get a shell"
        ],
        "useful_commands": ["ssh", "cat"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit19.html"]
    },
    20: {
        "level": "Level 19 → Level 20",
        "description": "To gain access to the next level, you should use the setuid binary in the home directory to execute a command as another user.",
        "objective": "Use the setuid binary to read the password file for the next level.",
        "hints": [
            "The setuid binary runs as bandit20 user",
            "It allows you to execute commands as bandit20",
            "The password file is in /etc/bandit_pass"
        ],
        "useful_commands": ["./bandit20-do", "whoami", "id"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit20.html"]
    },
    21: {
        "level": "Level 20 → Level 21",
        "description": "There is a setuid binary that connects to localhost on a port you specify. It then reads a line of text from the connection and compares it to the current level's password. If they match, it will transmit the password for the next level.",
        "objective": "Set up a listening service that sends the current password, then connect to it using the setuid binary.",
        "hints": [
            "You'll need two terminal windows or background processes",
            "One process needs to listen on a port",
            "The other process will connect to that port",
            "The listener must send the current level's password"
        ],
        "useful_commands": ["nc", "echo", "./suconnect", "&"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit21.html"]
    },
    22: {
        "level": "Level 21 → Level 22",
        "description": "A program is running automatically at regular intervals from cron, the time-based job scheduler. Look in /etc/cron.d/ for the configuration and see what command is being executed.",
        "objective": "Analyze the cronjob to find where the password is being written.",
        "hints": [
            "Check the cron job configuration files",
            "Look for shell scripts being executed",
            "Follow the trail of what the scripts do"
        ],
        "useful_commands": ["cat", "ls", "cron"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit22.html"]
    },
    23: {
        "level": "Level 22 → Level 23",
        "description": "A program is running automatically at regular intervals from cron. Look in /etc/cron.d/ to find out what command is being executed and what it does.",
        "objective": "Analyze the cronjob script and understand what it does to find the password.",
        "hints": [
            "The script processes usernames in a specific way",
            "Understanding the script will help you find where the password is stored",
            "You might need to replicate what the script does"
        ],
        "useful_commands": ["cat", "ls", "cron", "md5sum"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit23.html"]
    },
    24: {
        "level": "Level 23 → Level 24",
        "description": "A program is running automatically at regular intervals from cron. Look in /etc/cron.d/ to find out what command is being executed and what it does. Write a script to get the password.",
        "objective": "Write a script that will be executed by the cronjob to retrieve the password.",
        "hints": [
            "The script needs to be placed in a specific directory",
            "Make sure your script has the right permissions",
            "Create a script that reads and copies the password",
            "Use /tmp for your working directory"
        ],
        "useful_commands": ["mkdir", "cp", "chmod", "touch", "ls", "cat"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit24.html"]
    },
    25: {
        "level": "Level 24 → Level 25",
        "description": "A daemon is listening on port 30002 and will give you the password for bandit25 if given the password for bandit24 and a secret numeric 4-digit pincode.",
        "objective": "Write a script to brute force the 4-digit pin and get the password.",
        "hints": [
            "You'll need to try all possible 4-digit combinations",
            "Create a script to automate the process",
            "The script should send both the current password and the pin",
            "Be careful not to flood the service"
        ],
        "useful_commands": ["nc", "for", "while", "echo"],
        "resources": ["https://overthewire.org/wargames/bandit/bandit25.html"]
    }
    # More levels can be added here
}
